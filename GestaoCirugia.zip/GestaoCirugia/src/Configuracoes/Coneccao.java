/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Configuracoes;

import Modal.Erro505;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author José Artur Kassala
 */
public class Coneccao {
    
    public Connection ligar(){
        
        
        try {
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/artwillau", "root", "");
            //jdbc:mysql://localhost:3306/artwillau
            //jdbc:mysql://localhost:3306/artwillau
             //con.close();
        } catch (SQLException ex) {
            //System.out.println("Erro na coneccao #"+ex);
            new Erro505().setVisible(true);
            return null;
        }
        
    }
}
