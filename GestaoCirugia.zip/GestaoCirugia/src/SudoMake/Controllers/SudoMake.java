/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SudoMake.Controllers;

import Configuracoes.Coneccao;
import Modal.Erro505;
import java.awt.CardLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author José Artur Kassala
 */
public class SudoMake {

    private String bd, user, password;

    public String getBd() {
        return bd;
    }

    public void setBd(String bd) {
        this.bd = bd;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public SudoMake(String bd, String user, String password) {
        this.bd = bd;
        this.user = user;
        this.password = password;
    }

    public SudoMake() {

    }

    public Connection ligar() {

        try {
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/" + getBd(), getUser(), getPassword());

        } catch (SQLException ex) {
            System.out.println("Erro na coneccao #" + ex);
            new Erro505().setVisible(true);
            return null;
        }

    }

    public void mostrarCard(JPanel painelPai, String painelFilho) {
        CardLayout cl = (CardLayout) painelPai.getLayout();
        cl.show(painelPai, painelFilho);
    }

    public void limparTabela(JTable arg) {
        DefaultTableModel tabela = (DefaultTableModel) arg.getModel();
        System.out.println("lina " + tabela.getRowCount());
        if (tabela.getRowCount() > 0) {
            while (tabela.getRowCount() > 0) {
                // try {
                //arg.removeRowSelectionInterval(1, 5);
                System.out.println("| table: " + tabela.getRowCount());
                tabela.removeRow(0);
                /*  }catch(IllegalArgumentException ex){
                 System.out.println("Erro ao apagar");
                 }*/
            }
        }
    }

    public void actualizarTabela(JTable tabela, String query) {
        Connection con = new Coneccao().ligar();

        PreparedStatement consulta;
        try {

            limparTabela(tabela);

            consulta = con.prepareStatement(query);

            consulta.execute();
            ResultSet a = consulta.getResultSet();
            DefaultTableModel novos = (DefaultTableModel) tabela.getModel();

            while (a.next()) {
                Object[] obj = {a.getString(1), a.getInt(2), a.getDouble(3)};

                novos.addRow(obj);
            }
            a.close();
            consulta.close();

        } catch (SQLException ex) {
            System.out.println("Erro na Coneccao N# " + ex);
        }

    }

    public void actualizarTabela1(JTable tabela, String query) {
        Connection con = new Coneccao().ligar();

        PreparedStatement consulta;
        try {

            limparTabela(tabela);

            consulta = con.prepareStatement(query);

            consulta.execute();
            ResultSet a = consulta.getResultSet();
            DefaultTableModel novos = (DefaultTableModel) tabela.getModel();

            while (a.next()) {
                Object[] obj = {a.getString(1), a.getString(2), a.getString(3)};

                novos.addRow(obj);
            }
            a.close();
            consulta.close();

        } catch (SQLException ex) {
            System.out.println("Erro na Coneccao N# " + ex);
        }

    }

    public void mostrarComboBox(JComboBox comboBox, String consulta, String dados) {

        PreparedStatement query;
        try {

            query = this.ligar().prepareStatement(consulta);

            query.execute();
            ResultSet a = query.getResultSet();

            while (a.next()) {
                comboBox.addItem(a.getString(dados));

            }
            a.close();
            query.close();

        } catch (SQLException ex) {
            System.out.println("Erro na Coneccao");
        }
    }

    public String pegarComboBox(JComboBox comboBox, String consulta, String dados) {
        return null;
    }

    public String pegarDado(String query) throws SQLException {
        PreparedStatement consulta;

        consulta = this.ligar().prepareStatement(query);

        consulta.execute();
        ResultSet a = consulta.getResultSet();
        a.next();

        String resultado = a.getString(0);

        a.close();
        consulta.close();

        return resultado;
    }

    public int pegarDado(String query, String dado) throws SQLException {
        PreparedStatement consulta;

        consulta = this.ligar().prepareStatement(query);
        consulta.setString(1, dado);

        consulta.execute();
        ResultSet a = consulta.getResultSet();
        a.next();

        String resultado = a.getString(0);

        a.close();
        consulta.close();

        return Integer.parseInt(resultado);
    }

    public int pegarVal_id(String consulta, String resultado) {

        try {

            PreparedStatement query;

            query = this.ligar().prepareStatement(consulta);
            query.execute();

            ResultSet val = query.getResultSet();
            val.next();

            return val.getInt(resultado);

        } catch (SQLException ex) {
            System.out.println(ex);
            return 0;
        }
    }

    public String pegarVal_String(String consulta, String resultado) {

        try {

            PreparedStatement query;

            query = this.ligar().prepareStatement(consulta);
            query.execute();

            ResultSet val = query.getResultSet();
            val.next();

            return val.getString(resultado);

        } catch (SQLException ex) {
            System.out.println(ex);
            return null;
        }
    }

    public void listarTabela(JTable tabela, String consulta, String dados1, String dados2) {
        try {

            limparTabela(tabela);

            PreparedStatement query;
            query = this.ligar().prepareStatement(consulta);

            query.execute();
            ResultSet a = query.getResultSet();
            DefaultTableModel novos = (DefaultTableModel) tabela.getModel();
            System.out.println(tabela.getRowCount());

            System.out.println(tabela.getRowCount());
            while (a.next()) {
                Object[] obj = {a.getString(dados1), a.getString(dados2)};
                //System.out.println(a.getString("medicos")+" | "+a.getString("especialidade"));
                novos.addRow(obj);
            }
            a.close();
            query.close();

        } catch (SQLException ex) {
            System.out.println("Erro na Coneccao");
        }
    }

    public boolean salvarDados(String consulta) {

        try {
            PreparedStatement query;

            query = this.ligar().prepareStatement(consulta);

            query.execute();
            query.close();
            return true;
        } catch (SQLException ex) {
            return false;
        }

    }

    public void preencherTabela(JTable tabela, String consulta, String val, char tipo, String val1, char tipo1, String val2, char tipo2) {

        try {

            limparTabela(tabela);

            PreparedStatement query;
            query = this.ligar().prepareStatement(consulta);

            query.execute();
            try (ResultSet a = query.getResultSet()) {
                DefaultTableModel novos = (DefaultTableModel) tabela.getModel();
                System.out.println(tabela.getRowCount());

                System.out.println(tabela.getRowCount());

                while (a.next()) {

                    Object[] obj = {tipo == 's' ? a.getString(val) : tipo == 'i' ? a.getInt(val) : a.getDouble(val), tipo1 == 's' ? a.getString(val1) : tipo1 == 'i' ? a.getInt(val1) : a.getDouble(val1), tipo2 == 's' ? a.getString(val2) : tipo2 == 'i' ? a.getInt(val2) : a.getDouble(val2)};
                    //System.out.println(a.getString("medicos")+" | "+a.getString("especialidade"));
                    novos.addRow(obj);
                }
            }
            query.close();

        } catch (SQLException ex) {
            System.out.println("Erro na Coneccao");
        }

    }

    public void preencherTabela(JTable tabela, String consulta, String val, char tipo, String val1, char tipo1) {

        try {

            limparTabela(tabela);

            PreparedStatement query;
            query = this.ligar().prepareStatement(consulta);

            query.execute();
            try (ResultSet a = query.getResultSet()) {
                DefaultTableModel novos = (DefaultTableModel) tabela.getModel();
                System.out.println(tabela.getRowCount());

                System.out.println(tabela.getRowCount());

                while (a.next()) {

                    Object[] obj = {tipo == 's' ? a.getString(val) : tipo == 'i' ? a.getInt(val) : a.getDouble(val), tipo1 == 's' ? a.getString(val1) : tipo1 == 'i' ? a.getInt(val1) : a.getDouble(val1)};
                    //System.out.println(a.getString("medicos")+" | "+a.getString("especialidade"));
                    novos.addRow(obj);
                }
            }
            query.close();

        } catch (SQLException ex) {
            System.out.println("Erro na Coneccao");
        }

    }

    
    public void preencherTabela(JTable tabela, String consulta, String val, char tipo, String val1, char tipo1, String val2, char tipo2, String val3, char tipo3, String val4, char tipo4) {

        try {

            limparTabela(tabela);

            PreparedStatement query;
            query = this.ligar().prepareStatement(consulta);

            query.execute();
            try (ResultSet a = query.getResultSet()) {
                DefaultTableModel novos = (DefaultTableModel) tabela.getModel();
                System.out.println(tabela.getRowCount());

                System.out.println(tabela.getRowCount());

                while (a.next()) {

                    Object[] obj = {tipo == 's' ? a.getString(val) : tipo == 'i' ? a.getInt(val) : a.getDouble(val), tipo1 == 's' ? a.getString(val1) : tipo1 == 'i' ? a.getInt(val1) : a.getDouble(val1), tipo2 == 's' ? a.getString(val2) : tipo2 == 'i' ? a.getInt(val2) : a.getDouble(val2), tipo3 == 's' ? a.getString(val3) : tipo3 == 'i' ? a.getInt(val3) : a.getDouble(val3), tipo4 == 's' ? a.getString(val4) : tipo4 == 'i' ? a.getInt(val4) : a.getDouble(val4)};
                    //System.out.println(a.getString("medicos")+" | "+a.getString("especialidade"));
                    novos.addRow(obj);
                }
            }
            query.close();

        } catch (SQLException ex) {
            System.out.println("Erro na Coneccao");
        }

    }

    public void preencherTabela(JTable tabela, String consulta, String val, char tipo, String val1, char tipo1, String val2, char tipo2, String val3, char tipo3) {

        try {

            limparTabela(tabela);

            PreparedStatement query;
            query = this.ligar().prepareStatement(consulta);

            query.execute();
            try (ResultSet a = query.getResultSet()) {
                DefaultTableModel novos = (DefaultTableModel) tabela.getModel();
                System.out.println(tabela.getRowCount());

                System.out.println(tabela.getRowCount());

                while (a.next()) {

                    Object[] obj = {tipo == 's' ? a.getString(val) : tipo == 'i' ? a.getInt(val) : a.getDouble(val), tipo1 == 's' ? a.getString(val1) : tipo1 == 'i' ? a.getInt(val1) : a.getDouble(val1), tipo2 == 's' ? a.getString(val2) : tipo2 == 'i' ? a.getInt(val2) : a.getDouble(val2), tipo3 == 's' ? a.getString(val3) : tipo3 == 'i' ? a.getInt(val3) : a.getDouble(val3)};
                    //System.out.println(a.getString("medicos")+" | "+a.getString("especialidade"));
                    novos.addRow(obj);
                }
            }
            query.close();

        } catch (SQLException ex) {
            System.out.println("Erro na Coneccao");
        }

    }

    public boolean query_IUD(String consulta) {

        try {
            PreparedStatement query;

            query = this.ligar().prepareStatement(consulta);

            query.execute();
            query.close();
            return true;
        } catch (SQLException ex) {
            return false;
        }

    }

    public boolean isBI(String args) {

        String padrao = "\\d{9}[A-Z]{2}\\d{3}";
        Pattern compilacao = Pattern.compile(padrao);
        Matcher encontrar = compilacao.matcher(args);

        return encontrar.find();

    }
}
/*
 public void listar_Tabelas(JTable tabela, String consulta, String valor){
 try {

 limparTabela(tabela);
            
 PreparedStatement query;
 query = this.ligar().prepareStatement(consulta);

 query.execute();
 ResultSet a = query.getResultSet();
 DefaultTableModel novos = (DefaultTableModel) tabela.getModel();
 System.out.println(tabela.getRowCount());

 System.out.println(tabela.getRowCount());
 while (a.next()) {
 Object[] obj = {a.getString(dados1), a.getString(dados2)};
 //System.out.println(a.getString("medicos")+" | "+a.getString("especialidade"));
 novos.addRow(obj);
 }
 a.close();
 query.close();

 } catch (SQLException ex) {
 System.out.println("Erro na Coneccao");
 }
 }
 */
