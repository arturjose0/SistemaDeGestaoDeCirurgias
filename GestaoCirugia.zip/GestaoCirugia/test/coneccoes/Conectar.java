/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coneccoes;

import Configuracoes.Coneccao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author José Artur Kassala
 */
public class Conectar {
    
    public static void main(String args []){
        
        System.out.println("Ola teste");
        
        Connection con = new Coneccao().ligar();
        
        PreparedStatement query;
        try {
            query = con.prepareStatement("SELECT * FROM pacientes");
           // query.setString(1, "Testologia");
           query.execute();
           ResultSet a = query.getResultSet();
           
           while(a.next()){
                         System.out.println("Valores: "+a.getString(1));
           }
           a.close();
           query.close();
           
        } catch (SQLException ex) {
            System.out.println("Já existe um dados com essa informacao");
        }
        
        /*try {
            
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Conectar.class.getName()).log(Level.SEVERE, null, ex);
        }
        */
    }
    
}
